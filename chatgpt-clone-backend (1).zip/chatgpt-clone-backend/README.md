# ChatGPT Clone — Backend Setup Guide (Hinglish)

## Kya hai ye project?
Ye ek chhota Node.js + Express backend hai jo tumhare frontend (`public/index.html`) aur Anthropic API ke beech mein baithta hai. API key hamesha server pe rehti hai — browser mein kabhi nahi jaati.

---

## Step 1: Node.js check/install karo
Terminal/CMD mein type karo:
```
node -v
```
Agar version number aaye (jaise `v18.x.x` ya usse zyada) — good, aage badho.
Agar "command not found" aaye — [nodejs.org](https://nodejs.org) se LTS version install karo.

---

## Step 2: Dependencies install karo
Is folder ke andar terminal khol ke ye command chalao:
```
npm install
```
Ye `express` aur `dotenv` install kar dega.

---

## Step 3: API key set karo
1. `.env.example` file ko copy karke naam do `.env`
2. `.env` file kholo aur apni real API key daalo:
```
ANTHROPIC_API_KEY=sk-ant-tumhari-asli-key-yaha
PORT=3000
```
3. Key `console.anthropic.com` → Settings → API Keys se milegi.

⚠️ **`.env` file ko kabhi GitHub pe upload mat karna** — `.gitignore` mein already add kiya hai isko, to accidentally commit nahi hogi.

---

## Step 4: Server start karo
```
npm start
```
Terminal mein ye dikhega:
```
✅ Server running: http://localhost:3000
```

---

## Step 5: Browser mein kholo
Jao `http://localhost:3000` pe — tumhara ChatGPT clone chal raha hoga, real AI jawab dega, aur API key kahin bhi browser mein visible nahi hogi.

---

## College demo ke waqt kya bolna hai (quick points)
- "Frontend HTML/CSS/JS + Tailwind mein hai"
- "Backend Node.js + Express hai jo `/api/chat` endpoint expose karta hai"
- "API key sirf server ke `.env` file mein hai, kabhi client ko nahi bheji jaati — ye security best practice hai"
- "Backend Anthropic ke Claude API ko call karta hai aur real AI response deta hai"

---

## Common dikkatein (troubleshooting)
| Problem | Solution |
|---|---|
| `npm install` fail ho raha hai | Node.js version check karo (`node -v`), 18+ chahiye |
| Server start nahi ho raha | `.env` file bani hai kya check karo, `PORT` already use to nahi ho raha |
| "Server is missing ANTHROPIC_API_KEY" error | `.env` file mein key sahi se paste hui hai check karo, phir server restart karo |
| Response nahi aa raha / error aa raha hai | API key valid hai kya, credits khatam to nahi ho gaye — console.anthropic.com pe check karo |
